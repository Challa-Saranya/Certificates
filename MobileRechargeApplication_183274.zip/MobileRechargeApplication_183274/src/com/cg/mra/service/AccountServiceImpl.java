package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileException;

public class AccountServiceImpl implements AccountService{
	AccountDao accountdao;
	public AccountServiceImpl() {
		accountdao=new AccountDaoImpl();
	}

	@Override
	public Account getAccountDetails(String mobileNo) throws MobileException {
		// TODO Auto-generated method stub
		return accountdao.getAccountDetails(mobileNo);
	}

	@Override
	public int rechargeAmount(String mobileNo, double rechargeAmount) throws MobileException {
		// TODO Auto-generated method stub
		return accountdao.rechargeAccount(mobileNo, rechargeAmount);
	}
	public boolean validateMobile(Account account) throws MobileException
	{
	boolean flag=true;
	StringBuffer sb=new StringBuffer();
	if(!validateMobile(account.getMobileNo()))
	{
	sb.append("Invalid Mobile\n"); 
	flag=false;

	}
	if(flag)
	{
	return flag;
	}

	else {
	throw new MobileException(sb.toString());

	}

	}
	private boolean validateMobile(String mobile)
	{
	return mobile.matches("\\d{10}");
	}


}
