package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUi {
	static Scanner scanner=new Scanner(System.in);
	static AccountService accountservice=new AccountServiceImpl();
	public static void main(String[] args) {
		int response;
		while(true) {
			System.out.println("1)Account Balance Enquiry");
			System.out.println("2)Recharge Account");
			System.out.println("3)Exit");
			System.out.println("Enter your choice:");
			response=scanner.nextInt();
			scanner.nextLine();
			switch(response) {
			case 1:try {
					accountBalanceEnquiry();
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			       break;
			case 2:rechargeAccount();
			       break;
			case 3:System.exit(0);
			       break;
			default:System.out.println("Invalid option");
			        break;
			}
		}
	}
	private static void rechargeAccount() {
		// TODO Auto-generated method stub
		try {
      
		System.out.println("Enter Mobile No :");
		String mobileNo=scanner.next();
		System.out.println("Enter Recharge Amount:");
		double rechargeamount=scanner.nextDouble();
		scanner.nextLine();
			int account=accountservice.rechargeAmount(mobileNo, rechargeamount);
			Account accounts=accountservice.getAccountDetails(mobileNo);
			System.out.println("Hello"+accounts.getCustomerName()+", Available Balance is:"+accounts.getAccountBalance());
		}catch(MobileException e) {
			System.err.println("Cannot Recharge Account as Given Mobile No Does Not Exists"+e.getMessage());
		}
		
		
		
	}
	private static void accountBalanceEnquiry() throws MobileException {
		// TODO Auto-generated method stub
		Account account=new Account();
		System.out.println("Enter Mobile No :");
		String mobileNo=scanner.next();
		account.setMobileNo(mobileNo);
		boolean result=accountservice.validateMobile(account);
		Account acc=accountservice.getAccountDetails(mobileNo);
		System.out.println("Your Current Balance is : "+acc.getAccountBalance());

	}
}
