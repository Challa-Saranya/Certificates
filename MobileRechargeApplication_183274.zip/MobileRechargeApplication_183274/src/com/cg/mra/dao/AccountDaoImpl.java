package com.cg.mra.dao;

import java.util.HashMap;
/***
 * Author :Challa Saranya
 * Created on : 10-07-2019
 * purpose: This class is used for accessing and performing
 * different data access operations
 *
 */
import java.util.Map;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;

public class AccountDaoImpl implements AccountDao {
	private static Map<String,Account> accountmap=new HashMap<String,Account>();
	static {
		accountmap.put("9922943943",new Account("9922943943","debit","Saranya",500.00));
		accountmap.put("9247474145",new Account("9247474145","credit","Sowmya",10000.00));
		accountmap.put("9247478934",new Account("9247478934","debit","Sarala",7000.00));
		accountmap.put("9247474198",new Account("9247474198","credit","Siddu",20000.00));
	}
	public static Map<String,Account> getAccountDb(){
		return accountmap;
	}
	/***
	 * Author :Challa Saranya
	 * Date od Creation : 10-07-2019
	 * Method Name: getAccountDetails
	 * parameters : None
	 * return value : Account mobilenumber
	 * purpose : Retrieves all the data from the mobileDb
	 */


	@Override
	public Account getAccountDetails(String mobileNo) throws MobileException{
		// TODO Auto-generated method stub
		if(accountmap.containsKey(mobileNo)) {
			return accountmap.get(mobileNo);
		}
		else {
			throw new MobileException("Account Id doesnot exist");
		}
		
	}
	/***
	 * Author :Challa Saranya
	 * Date od Creation : 10-07-2019
	 * Method Name: rechargeAccount
	 * parameters : None
	 * return value : accountbalance
	 * purpose : Retrieves all the data from the mobileDb
	 */

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws MobileException {
		// TODO Auto-generated method stub
		if(accountmap.containsKey(mobileNo)) {
			Account account=accountmap.get(mobileNo);
			account.setAccountBalance(account.getAccountBalance()+rechargeAmount);
			accountmap.put(mobileNo, account);
			return (int)account.getAccountBalance();
			
		}
		else {
			throw new MobileException("Account Id doesnot exist");
		}
		
	}

}
