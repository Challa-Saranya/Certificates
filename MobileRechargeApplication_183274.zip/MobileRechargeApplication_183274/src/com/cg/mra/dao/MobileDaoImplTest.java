/**
 *  @author Challa Saranya
 *  Date of creation: 10-07-2019
 *  Purpose: These test cases are used to test MobileDaoImpl class
 */
package com.cg.mra.dao;

import static org.junit.Assert.assertEquals;


import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.beans.Account;

import org.junit.Test;

import com.cg.mra.exception.MobileException;

public class MobileDaoImplTest {

	@Test
	public void testrechargeAccount(double rechargeAmount, String mobileNo) throws MobileException {
		AccountDao accountdao=new AccountDaoImpl();
		Account account=new Account();
		account.setAccountBalance(500.00);
		account.setAccountType("debit");
		account.setCustomerName("Saranya");
		account.setMobileNo("9247474199");
		String mobileNo1="9247474199";
	 int account1=accountdao.rechargeAccount(mobileNo,rechargeAmount);
	 int account2=accountdao.rechargeAccount(mobileNo1,rechargeAmount);
	 assertEquals("9247474199",account1);
	 
	
	}
	

}
